"use strict";
    const form = document.getElementById("serviceForm");
    const serviceBoxes = Array.from(document.querySelectorAll('input[name="services[]"]'));
    const fullServiceBox = document.getElementById("fullService");
    const diagnosisBox = document.getElementById("computerDiagnosis");
    const estimateList = document.getElementById("estimateList");
    const estimateTotal = document.getElementById("estimateTotal");
    const estimateCount = document.getElementById("estimateCount");
    const servicePrices = {"Engine Oil Change":3000,"Brake Inspection":2000,"Wheel Alignment":2500,"Computer Diagnosis":3500,"Full Service":8000};
    let diagnosisAddedByOffer = false;
    let lastTotal = 0;
    const today = new Date();
    const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0,10);
    const yearInput = document.getElementById("year");
    document.getElementById("service_date").min = localToday;
    yearInput.max = String(new Date().getFullYear() + 1);

    function formatMoney(amount) {
      return "KSh " + Number(amount).toLocaleString("en-KE");
    }

    // Full Service adds diagnosis at zero cost. Track whether the offer added it
    // so it can be removed when Full Service is unticked.
    function applyDiagnosisOffer() {
      const freeTag = document.getElementById("diagnosisFreeTag");
      const optionFree = document.getElementById("diagnosisOptionFree");
      const diagnosisPrice = document.getElementById("diagnosisPrice");
      const optionPrice = document.getElementById("diagnosisOptionPrice");
      if (fullServiceBox.checked) {
        if (!diagnosisBox.checked) {
          diagnosisBox.checked = true;
          diagnosisAddedByOffer = true;
        }
        freeTag.hidden = false;
        optionFree.hidden = false;
        diagnosisPrice.innerHTML = '<del>KSh 3,500</del>';
        optionPrice.innerHTML = '<del>KSh 3,500</del>';
      } else {
        if (diagnosisAddedByOffer) diagnosisBox.checked = false;
        diagnosisAddedByOffer = false;
        freeTag.hidden = true;
        optionFree.hidden = true;
        diagnosisPrice.textContent = "KSh 3,500";
        optionPrice.textContent = "KSh 3,500";
      }
    }

    function selectedServices() {
      return serviceBoxes.filter(box => box.checked).map(box => ({
        name: box.value,
        price: fullServiceBox.checked && box.value === "Computer Diagnosis" ? 0 : servicePrices[box.value],
        free: fullServiceBox.checked && box.value === "Computer Diagnosis"
      }));
    }

    // Keep the estimate display and live total in sync with selected checkboxes.
    function updateEstimate() {
      const selected = selectedServices();
      const total = selected.reduce((sum, service) => sum + service.price, 0);
      estimateList.replaceChildren();
      if (!selected.length) {
        const empty = document.createElement("li");
        empty.className = "empty";
        empty.textContent = "Choose a service to get started.";
        estimateList.appendChild(empty);
      } else {
        selected.forEach(service => {
          const item = document.createElement("li");
          const name = document.createElement("span");
          const price = document.createElement("strong");
          name.textContent = service.name;
          price.textContent = service.free ? "FREE" : formatMoney(service.price);
          if (service.free) price.style.color = "var(--green)";
          item.append(name, price);
          estimateList.appendChild(item);
        });
      }
      estimateCount.textContent = `${selected.length} ${selected.length === 1 ? "service" : "services"} selected`;
      estimateTotal.textContent = formatMoney(total);
      if (total !== lastTotal) {
        estimateTotal.classList.remove("bump");
        void estimateTotal.offsetWidth;
        estimateTotal.classList.add("bump");
      }
      lastTotal = total;
    }

    function checkVehicleAge() {
      const year = Number(yearInput.value);
      const validYear = yearInput.value !== "" && Number.isInteger(year) && year >= 1950 && year <= new Date().getFullYear() + 1;
      document.getElementById("ageWarning").hidden = !(validYear && year < 2005);
      document.getElementById("recommendedBadge").hidden = !(validYear && year < 2005);
      return validYear;
    }

    function setError(fieldName, message) {
      const field = form.elements[fieldName];
      const error = document.getElementById(`${fieldName}-error`);
      if (error) error.textContent = message;
      if (field && field.classList) {
        field.classList.toggle("invalid", Boolean(message));
        if (message) field.setAttribute("aria-invalid", "true");
        else field.removeAttribute("aria-invalid");
      }
    }

    function validateField(name) {
      const value = (form.elements[name]?.value || "").trim();
      let message = "";
      const maxYear = new Date().getFullYear() + 1;
      switch (name) {
        case "customer_name": if (!value) message = "Please enter your full name."; break;
        case "phone": if (!/^\d{10}$/.test(value)) message = "Enter exactly 10 digits, with no spaces."; break;
        case "email": if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) message = "Enter a valid email address."; break;
        case "reg_number": if (!value) message = "Please enter your vehicle registration."; break;
        case "vehicle_type": if (!["Saloon Car","SUV","Pickup","Van"].includes(value)) message = "Please choose a vehicle type."; break;
        case "vehicle_model": if (!value) message = "Please enter the vehicle make and model."; break;
        case "year": {
          const year = Number(value);
          if (!value || !Number.isInteger(year) || year < 1950 || year > maxYear) message = `Enter a whole year from 1950 to ${maxYear}.`;
          checkVehicleAge();
          break;
        }
        case "service_date": {
          const parsedDate = /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(value + "T00:00:00Z") : null;
          const isRealDate = parsedDate && !Number.isNaN(parsedDate.getTime()) && parsedDate.toISOString().slice(0, 10) === value;
          if (!value || !isRealDate || value < localToday) message = "Choose a real date that is today or later.";
          break;
        }
      }
      setError(name, message);
      return !message;
    }

    function validateServiceForm(event) {
      const names = ["customer_name","phone","email","reg_number","vehicle_type","vehicle_model","year","service_date"];
      let firstInvalid = null;
      names.forEach(name => {
        if (!validateField(name) && !firstInvalid) firstInvalid = form.elements[name];
      });
      const servicesError = document.getElementById("services-error");
      const hasService = serviceBoxes.some(box => box.checked);
      servicesError.textContent = hasService ? "" : "Select at least one service.";
      if (!hasService && !firstInvalid) firstInvalid = serviceBoxes[0];
      if (firstInvalid) {
        event.preventDefault();
        firstInvalid.focus();
        firstInvalid.scrollIntoView({behavior:"smooth",block:"center"});
        return false;
      }
      return true; // Let the browser submit normally to process_service.php.
    }

    // Re-check individual fields as the user edits or leaves them.
    ["customer_name","phone","email","reg_number","vehicle_type","vehicle_model","year","service_date"].forEach(name => {
      const field = form.elements[name];
      field.addEventListener("input", () => validateField(name));
      field.addEventListener("change", () => validateField(name));
      field.addEventListener("blur", () => validateField(name));
    });
    serviceBoxes.forEach(box => box.addEventListener("change", () => {
      if (box === fullServiceBox) {
        applyDiagnosisOffer();
      } else if (box === diagnosisBox) {
        if (fullServiceBox.checked && !diagnosisBox.checked) {
          // Diagnosis is part of the offer, so it cannot be removed while Full Service is selected.
          diagnosisBox.checked = true;
        } else if (!fullServiceBox.checked) {
          diagnosisAddedByOffer = false;
        }
      }
      document.getElementById("services-error").textContent = serviceBoxes.some(item => item.checked) ? "" : "Select at least one service.";
      updateEstimate();
    }));
    form.addEventListener("submit", validateServiceForm);

    document.getElementById("vehicle_type").addEventListener("change", event => {
      const tips = {
        "Saloon Car":"Tip: Share the exact model and engine size if you know it.",
        "SUV":"Tip: Mention any 4WD or drivetrain warning lights when we follow up.",
        "Pickup":"Tip: Let us know if the vehicle is mainly used for heavy loads or off-road driving.",
        "Van":"Tip: If the van carries loads regularly, mention this when the team contacts you."
      };
      document.getElementById("vehicleTip").textContent = tips[event.target.value] || "Choose a vehicle type to see a helpful tip.";
    });
    yearInput.addEventListener("input", checkVehicleAge);
    yearInput.addEventListener("change", checkVehicleAge);

    // Mobile navigation controls.
    const menuToggle = document.getElementById("menuToggle");
    const navLinks = document.getElementById("navLinks");
    menuToggle.addEventListener("click", () => {
      const open = navLinks.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(open));
      menuToggle.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
    });
    navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      navLinks.classList.remove("open");
      menuToggle.setAttribute("aria-expanded","false");
    }));

    // Theme preference is kept for the current page session only.
    document.getElementById("themeToggle").addEventListener("click", () => {
      document.body.classList.toggle("dark");
      document.getElementById("themeToggle").setAttribute("aria-pressed", String(document.body.classList.contains("dark")));
    });

    // Accessible FAQ accordion.
    document.querySelectorAll(".faq-question").forEach(button => button.addEventListener("click", () => {
      const item = button.closest(".faq-item");
      const open = item.classList.toggle("open");
      button.setAttribute("aria-expanded", String(open));
    }));

    // Reveal sections gently as they enter the viewport; show everything if unsupported.
    if ("IntersectionObserver" in window) {
      const observer = new IntersectionObserver(entries => entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      }), {threshold:.12});
      document.querySelectorAll(".reveal").forEach(element => observer.observe(element));
    } else {
      document.querySelectorAll(".reveal").forEach(element => element.classList.add("visible"));
    }
    document.getElementById("currentYear").textContent = new Date().getFullYear();
    applyDiagnosisOffer();
    updateEstimate();
