<?php
declare(strict_types=1);

/*
 * AutoCare Garage booking handler.
 * Save this file beside index.html in the XAMPP htdocs/autocare directory.
 */

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.html');
    exit;
}

date_default_timezone_set('Africa/Nairobi');

function clean_post(string $key): string {
    $value = $_POST[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}

function escape_html(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function render_page_start(string $title): void {
    $safeTitle = escape_html($title);
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . $safeTitle . ' | AutoCare Garage</title>';
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
    echo '<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">';
    echo '<style>
      :root{--orange:#ff6a00;--charcoal:#2b2b2e;--black:#161618;--bg:#f2f1ef;--surface:#fff;--ink:#202023;--muted:#66666c;--line:#e4e2df;--red:#b4232d;--green:#16834a}
      *{box-sizing:border-box}body{margin:0;padding:28px 16px;background:var(--bg);color:var(--ink);font-family:"Barlow",Arial,sans-serif;line-height:1.55}.wrap{max-width:850px;margin:0 auto}.top{background:var(--black);color:#fff;padding:22px 26px;border-radius:16px 16px 0 0;display:flex;align-items:center;gap:12px}.logo{width:40px;height:40px;background:var(--orange);border-radius:10px;display:grid;place-items:center;font-size:1.4rem;font-weight:900}.brand{font-size:1.2rem;font-weight:900}.card{background:var(--surface);padding:clamp(22px,5vw,38px);border:1px solid var(--line);border-top:4px solid var(--orange);border-radius:0 0 16px 16px;box-shadow:0 15px 40px rgba(20,20,22,.09)}.eyebrow{font-size:.78rem;font-weight:900;letter-spacing:.15em;color:var(--orange)}h1{font-size:clamp(1.8rem,5vw,2.7rem);line-height:1.05;margin:9px 0 10px;font-weight:900}p{margin-top:0}.lead{color:var(--muted);margin-bottom:25px}.details{display:grid;grid-template-columns:1fr 1fr;gap:0 24px;margin:20px 0 28px}.detail{padding:12px 0;border-bottom:1px solid var(--line);min-width:0}.detail span{display:block;color:var(--muted);font-size:.82rem;font-weight:600}.detail strong{display:block;overflow-wrap:anywhere;font-size:1.03rem}.section-title{font-size:1.2rem;margin:28px 0 8px}.services{list-style:none;padding:0;margin:0}.services li{display:flex;justify-content:space-between;gap:16px;padding:12px 0;border-bottom:1px solid var(--line)}.services li span:first-child{overflow-wrap:anywhere}.free{color:var(--green);font-weight:800}.total{margin-top:24px;padding:20px;border-radius:12px;background:var(--charcoal);color:#fff;display:flex;justify-content:space-between;align-items:center;gap:16px}.total span{font-weight:800;letter-spacing:.05em;font-size:.9rem}.total strong{font-size:clamp(1.4rem,4vw,2rem);color:#ff8a38;white-space:nowrap}.reference{margin-top:22px;padding:14px;background:#fff3e9;border:1px dashed #ff9b57;border-radius:10px}.reference span{display:block;color:#7d3c08;font-size:.8rem;font-weight:800}.reference strong{font-size:1.15rem;letter-spacing:.06em}.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:26px}.btn{display:inline-flex;align-items:center;justify-content:center;padding:12px 18px;border-radius:9px;background:var(--orange);color:#fff;text-decoration:none;font-weight:800;border:0}.btn.secondary{background:transparent;color:var(--ink);border:1px solid var(--line)}.errors{padding-left:22px;color:var(--red)}.errors li{margin:7px 0}.note{font-size:.86rem;color:var(--muted);margin-top:22px}.footer{text-align:center;color:var(--muted);font-size:.83rem;margin:18px 0}@media(max-width:560px){body{padding:14px 10px}.top{padding:17px}.details{grid-template-columns:1fr}.total{align-items:flex-start;flex-direction:column}.services li{font-size:.95rem}}
    </style></head><body><main class="wrap"><header class="top"><div class="logo" aria-hidden="true">A</div><div class="brand">AutoCare Garage</div></header>';
}

function render_page_end(): void {
    echo '<p class="footer">AutoCare Garage · Vehicle care with clarity.</p></main></body></html>';
}

$customerName = clean_post('customer_name');
$phone = clean_post('phone');
$email = clean_post('email');
$registration = strtoupper(clean_post('reg_number'));
$vehicleType = clean_post('vehicle_type');
$vehicleModel = clean_post('vehicle_model');
$yearRaw = clean_post('year');
$dateRaw = clean_post('service_date');

$allowedTypes = ['Saloon Car', 'SUV', 'Pickup', 'Van'];
$priceList = [
    'Engine Oil Change' => 3000,
    'Brake Inspection' => 2000,
    'Wheel Alignment' => 2500,
    'Computer Diagnosis' => 3500,
    'Full Service' => 8000,
];

$errors = [];
if ($customerName === '') $errors[] = 'Full name is required.';
if (!preg_match('/^\d{10}$/', $phone)) $errors[] = 'Phone number must contain exactly 10 digits.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
if ($registration === '') $errors[] = 'Vehicle registration is required.';
if (!in_array($vehicleType, $allowedTypes, true)) $errors[] = 'Choose a valid vehicle type.';
if ($vehicleModel === '') $errors[] = 'Vehicle make and model are required.';

$maxYear = (int)date('Y') + 1;
$year = filter_var($yearRaw, FILTER_VALIDATE_INT);
if ($year === false || $year === null || $year < 1950 || $year > $maxYear) {
    $errors[] = "Year of manufacture must be a whole number from 1950 to {$maxYear}.";
}

$dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $dateRaw);
$dateErrors = DateTimeImmutable::getLastErrors();
$dateIsReal = $dateObject !== false
    && ($dateErrors === false || ($dateErrors['warning_count'] === 0 && $dateErrors['error_count'] === 0))
    && $dateObject->format('Y-m-d') === $dateRaw;
$today = new DateTimeImmutable('today');
if (!$dateIsReal || $dateObject < $today) {
    $errors[] = 'Choose a real service date that is today or later.';
}

// Accept only string service names. Ignore unknown entries and de-duplicate safely.
$submittedServices = $_POST['services'] ?? [];
if (!is_array($submittedServices)) $submittedServices = [];
$selectedNames = [];
foreach ($submittedServices as $submittedService) {
    if (!is_string($submittedService)) continue;
    $serviceName = trim($submittedService);
    if (array_key_exists($serviceName, $priceList) && !in_array($serviceName, $selectedNames, true)) {
        $selectedNames[] = $serviceName;
    }
}
if (count($selectedNames) === 0) {
    $errors[] = 'Select at least one valid service.';
}

// Server-side offer: diagnosis is included at zero cost with Full Service.
if (in_array('Full Service', $selectedNames, true) && !in_array('Computer Diagnosis', $selectedNames, true)) {
    $selectedNames[] = 'Computer Diagnosis';
}
$serviceRows = [];
foreach ($selectedNames as $serviceName) {
    $isFreeDiagnosis = $serviceName === 'Computer Diagnosis' && in_array('Full Service', $selectedNames, true);
    $serviceRows[] = [
        'name' => $serviceName,
        'price' => $isFreeDiagnosis ? 0 : $priceList[$serviceName],
        'free' => $isFreeDiagnosis,
    ];
}
// Calculate from our trusted server-side price list, never from browser data.
$total = array_sum(array_column($serviceRows, 'price'));

if ($errors) {
    http_response_code(422);
    render_page_start('Booking details need attention');
    echo '<section class="card"><div class="eyebrow">BOOKING NOT SUBMITTED</div><h1>Please check your details</h1>';
    echo '<p class="lead">We could not process the request yet. Correct the following items and submit the form again.</p>';
    echo '<ul class="errors">';
    foreach ($errors as $error) echo '<li>' . escape_html($error) . '</li>';
    echo '</ul><div class="actions"><a class="btn" href="index.html#booking">Go back</a></div></section>';
    render_page_end();
    exit;
}

// Generate a display reference for this request. This is a reference, not a persisted database ID.
try {
    $reference = 'ACG-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
} catch (Throwable $exception) {
    $reference = 'ACG-' . date('ymd') . '-' . strtoupper(substr(sha1(uniqid('', true)), 0, 6));
}
$formattedDate = $dateObject->format('j F Y');

render_page_start('Service Request Received');
echo '<section class="card"><div class="eyebrow">SERVICE REQUEST RECEIVED</div>';
echo '<h1>Thanks, ' . escape_html($customerName) . '.</h1>';
echo '<p class="lead">Your service request has been prepared successfully. The estimated cost below is based on the services selected. Please wait for the garage to confirm appointment availability.</p>';

echo '<div class="details">';
$details = [
    'Customer' => $customerName,
    'Phone' => $phone,
    'Email' => $email,
    'Vehicle registration' => $registration,
    'Vehicle Type' => $vehicleType,
    'Model and Year' => $vehicleModel . ' · ' . (string)$year,
    'Service Date' => $formattedDate,
];
foreach ($details as $label => $value) {
    echo '<div class="detail"><span>' . escape_html($label) . '</span><strong>' . escape_html($value) . '</strong></div>';
}
echo '</div>';

echo '<h2 class="section-title">Selected Services</h2><ul class="services">';
foreach ($serviceRows as $row) {
    echo '<li><span>' . escape_html($row['name']) . '</span><strong' . ($row['free'] ? ' class="free"' : '') . '>';
    echo $row['free'] ? 'FREE (included with Full Service)' : escape_html('KSh ' . number_format($row['price']));
    echo '</strong></li>';
}
echo '</ul>';

echo '<div class="total"><span>ESTIMATED SERVICE COST</span><strong>' . escape_html('KSh ' . number_format($total)) . '</strong></div>';
echo '<div class="reference"><span>BOOKING REFERENCE</span><strong>' . escape_html($reference) . '</strong></div>';
echo '<p class="note">Keep this reference for your records. This demo processes the request and displays a confirmation page, but does not save bookings to a database or send an email automatically.</p>';
echo '<div class="actions"><a class="btn" href="index.html">Make another booking</a><a class="btn secondary" href="index.html#services">View services</a></div></section>';
render_page_end();
?>
